# Change Log

## Version 1.3.1

1. Back qrcode library to ^2.5

## Version 1.3.0
1. Update qrcode library version to 3

## Version 1.2.0

1. BarCode: Use `onRender()` function instead of `render()`
2. QRCode: Use `onRender()` function instead of `render()`
3. Change qrcode library